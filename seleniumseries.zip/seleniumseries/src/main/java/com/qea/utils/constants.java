package com.qea.utils;

public class constants {

}
