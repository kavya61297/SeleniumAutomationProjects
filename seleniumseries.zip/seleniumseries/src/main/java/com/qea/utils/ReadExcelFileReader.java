package com.qea.utils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import java.io.FileInputStream;
import java.io.IOException;

public class ReadExcelFileReader {
	
    public static Object[][] getExcelData(String sheetname , String filepath) {
        Object[][] data = null;
        
        try (FileInputStream fis = new FileInputStream(filepath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            // Access the first sheet in the Excel file
            Sheet sheet = workbook.getSheetAt(0);
            int numRows = sheet.getPhysicalNumberOfRows();
            int rowCount = sheet.getPhysicalNumberOfRows();
            int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
            data = new Object[rowCount - 1][colCount];
            for(int i = 1; i < numRows; i++ ) {
            	Row currentRow = sheet.getRow(i);
            	int lastCol = currentRow.getLastCellNum();
            	for(int j = 0; j < lastCol; j++) {       
            		Cell currentcell = currentRow.getCell(j);
            		if (currentcell == null) {
            			data[i-1][j] = "";
            			continue;
            		}
            		switch (currentcell.getCellType()) {
	                   case STRING:
	                         data[i-1][j] = currentcell.getStringCellValue();
	                         break;
	                     case NUMERIC:
	                         data[i-1][j] = currentcell.getNumericCellValue();
	                         break;
	                     case BOOLEAN:
	                         data[i-1][j] = currentcell.getBooleanCellValue();
	                         break;
	                     case BLANK:
	                    	 data[i-1][j] = "";
	                         break;
	                     default:
	                         data[i-1][j] = "";
	                         break;
            		} 
     
            		System.out.println(data[i-1][j]);
            	
            	}
            	System.out.println("\n");
            }

          
        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }

}

