package com.qea.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {
	
	
	//public WebDriver driver;
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
	//Thread local drive for parallel execution
	
	/*This Method is used to initialize the threadlocal driver
	 * this will return tlDriver*
	 * @param browser*/
	public static WebDriver init_driver(String browser) {
		
		System.out.println("browser value is: " + browser);
		
		if (browser.equals("chrome")) {
			//ChromeOptions options = new ChromeOptions();
			//options.setHeadless(true);
			//options.addArguments("--headless=new");
			WebDriverManager.chromedriver().setup();
			//tlDriver.set(new ChromeDriver(options));
			tlDriver.set(new ChromeDriver());
		} else if (browser.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			tlDriver.set(new FirefoxDriver());
		} else {
			System.out.println("Please pass the correct browser value: " + browser);
		}

		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().maximize();
		return getDriver();
	
	}
 
	public static synchronized WebDriver getDriver() {
		
		System.out.println("Driver value :" + tlDriver.get());
		return tlDriver.get();
		
	}
}
