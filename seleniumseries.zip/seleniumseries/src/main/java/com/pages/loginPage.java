package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class loginPage {
	
	
	private WebDriver driver;
	
	//1. By Locator
	private By welcompage= By.xpath("//*[@id=\"applicationContainer\"]/div/span[1]");
	private By loginbutton =By.xpath("//*[@id=\"applicationContainer\"]/div/div/button");
	private By enteryourOrganization = By.xpath("//input[@id='organizationName']");
	private By continueButton = By.xpath("/html/body/div/main/section/div/div/div/form/div[2]/button");
	//private By loginButton = By.cssSelector("input[type='button']");
	//private By loginButton = By.cssSelector("MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium fv-login ms-3 mt-5 css-12fuqtd");
	private By paragraphName =By.className("c4bb6cb5d c271e25f3");
	private By titlewelcome = By.xpath("//*[@id=\"applicationContainer\"]/div[3]/div/div[1]/span/span[2]");
	private By emailId = By.id("username");
	private By passWord = By.id("password");
	private By forgotPassword = By.linkText("Forgot password?");



	
	
	
public loginPage(WebDriver driver) {
	this.driver = driver;
	
}
public String getfirstPageText() {
	return (new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(welcompage)).getText());
}
public void clickLogin() {
	
	driver.findElement(loginbutton).click();
	
}
public String loginPageParagraph() {
	
	return driver.findElement(paragraphName).getText();
	
}
// 3. page actions: features(behavior) of the page all form methods:

public String getLoginPageTitle() {
	return driver.getTitle();
}

public boolean isForgotPwdLinkExist() {
	return driver.findElement(forgotPassword).isDisplayed();
}
public void enterUserName(String usernm) {
	driver.findElement(emailId).sendKeys(usernm);
}
public void enterPassword(String pwd) {
	driver.findElement(passWord).sendKeys(pwd);
}

public void enterOrgName(String orgname) {
	driver.findElement(enteryourOrganization).sendKeys(orgname);
}

public void clickOnContinue() {
	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	driver.findElement(continueButton).click();}

public void clickToContinue() {
	//new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[class='c227b20f2 c8e6e34f8 c06daa549 c0fe4fa86 cf42875ec'"))).click();
	
	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/main/section/div/div/div/form/div[2]/button"))).click();
}

public void clickOnLogin() {
	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[class='MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium fv-login ms-3 mt-5 css-12fuqtd'"))).click();
}

//wait 
public String titlePage() {
	return (new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(titlewelcome)).getText());
	//return driver.findElement(titlewelcome).getText();
}




}
