package com.pages;

import java.util.concurrent.TimeoutException;

import org.bouncycastle.jcajce.provider.asymmetric.EC;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.ExpectedConditions.EC;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qea.utils.ReadExcelFileReader;

public class FacctViewLoginPage {
	
	

	private WebDriver driver;
	
	
	String excelFilePath = "C:\\Users\\KavyaS\\Documents\\Facctview\\TestData\\dsAlgoData.xlxs";
	//1. By Locator
	private By startPageText = By.xpath("//*[@id=\"applicationContainer\"]/div[1]/div[2]/span[2]"); //changed from span[2] to [1]
	//private By loginButton =By.xpath("//*[@id=\"applicationContainer\"]/div[1]/div[2]/div/div/button");
	private By loginButton =By.xpath("(//button[@type='button'])[2]");
	///html/body/div[1]/div/div/div/div[1]/div[2]/div/div/button
	private By orgName = By.id("organizationName");
	private By continueButton = By.xpath("//button[@name = \"action\"]");
	private By contButton = By.xpath("/html/body/div/main/section/div/div/div/form/div[2]/button");
	private By emailId = By.id("username");
	private By passWord = By.id("password");
	private By loginButtont =By.xpath("//button[@name='action' and @value='default' and @data-action-button-primary='true']");
	private By welcomePage = By.xpath("//*[@id=\"instantScreening\"]/div[1]/div/h6");
	private By forgotPassword = By.linkText("Forgot password?");
	//WebDriverWait wait = new WebDriverWait(driver, 20);
	//WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@aria-invalid='false' and @aria-label='Search']")));
	private By textbox = By.xpath("//input[@name = \"searchInputs\"]");
	//*[@id=":rf:"]
	private By idnumbox = By.xpath("//input[@id=\"national-id\"]");
	private By countrydropdown = By.xpath("//div[@id='country-select']");
	private By dropdownbutton = By.xpath("//button[@data-testid=\"additional-filters\"]");
	private By citytxt = By.xpath("//input[@id=\"City\"]");
	private By codebox = By.xpath("//input[@id=\"Postal Code\"]");
	private By searchButton = By.xpath("//button[@data-testid='search-button']");
	//button[@data-testid=\"search-button\"]
	private By dropDownButton = By.xpath("//div[@id=\"country-select\"]");
	private By addressbox =  By.xpath("//input[@id=\"Address Line\"]");
	private By sideDropButton = By.xpath("//div[@id='searchResultContainer']//div[@class='search-row  d-flex flex-column p-2 mb-2'][1]//div[@role='button']");
			//By.xpath("(//*[name()='svg']//*[local-name()='path' and @d='m10 17 5-5-5-5z'])[1]");
	// //li[@data-value="Switzerland"]




public String getLoginPageText() {
	return (new WebDriverWait(driver, 60).until(ExpectedConditions.presenceOfElementLocated(startPageText)).getText());
}	
//public String getLoginPageText() {
		  //if (driver.findElement(startPageText).isDisplayed()) {
		    //return new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(startPageText)).getText();	}
		//return null;
//}
//public String getLoginPageText() {
	 // try {
	    //return new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(startPageText)).getText();
	 //   // Handle null pointer exception (e.g., log error, fail test)
	   // return null;
	 // }
	//}

//public String getLoginPageText() {
	  //try {
	    //return driver.findElement(startPageText).getText();
	  //} catch (NullPointerException e) {
	    // Handle null pointer exception (e.g., log error, fail test)
	   // return null;
	  //}
	//}
//public class CustomConditions {
    //public static ExpectedCondition<String> textPresent(final String text) {
        //return new ExpectedCondition<String>() {
            //public String apply(WebDriver driver) {
               // WebElement element = driver.findElement(By.xpath("//*[@id=\\\"applicationContainer\\\"]/div[1]/div[2]/span[2]"));
               // if (element.getText().contains(text)) {
               //     return element.getText();
               // } else {
               //     return null;
              //  }
          //  }
      //  };
   // }
//}

public FacctViewLoginPage(WebDriver driver) {
    this.driver = driver;
  } 


public void clickLoginButton() {
	
	driver.findElement(loginButton).click();
	
}
// 3. page actions: features(behavior) of the page all form methods:

public void enterOrgName(String orgname) {
	driver.findElement(orgName).sendKeys(orgname);
}
public void clickcontButton() {
	
	//driver.findElement(contButton).click();
	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(contButton)).click();
}


public boolean isForgotPwdLinkExist() {
	return driver.findElement(forgotPassword).isDisplayed();
}
public void enterUserName(String usernm) {
	driver.findElement(emailId).sendKeys(usernm);
}
public void enterPassword(String pwd) {
	driver.findElement(passWord).sendKeys(pwd);
}

public void clickonLoginButtonT() {
	
	driver.findElement(loginButtont).click();
	
}

public String getWelcomePageText() {
	return (new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(welcomePage)).getText());
}

public void clickOnContinue() {
	//driver.findElement(continueButton).click();
	
	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(continueButton)).click();}

public void clickToContinue() {
	//new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[class='c227b20f2 c8e6e34f8 c06daa549 c0fe4fa86 cf42875ec'"))).click();
	
	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/main/section/div/div/div/form/div[3]/button"))).click();
}

public void clickOnLogin() {
	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[class='MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium fv-login ms-3 mt-5 css-12fuqtd'"))).click();
}

public void searchText(String srchtxt) {
	WebDriverWait wait = new WebDriverWait(driver, 10);
	WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(textbox));
	element.sendKeys(srchtxt);
	//WebElement element = driver.findElement(searchBox); 
}

public void enterIdNumber(String idNumbr) {
	driver.findElement(idnumbox).sendKeys(idNumbr);
}

public void clickDropButton() {
	driver.findElement(dropdownbutton).click();
}

public void enterAddressLine(String addressln) {
	driver.findElement(addressbox).sendKeys(addressln);
}

public void enterCity(String cty) {
	driver.findElement(citytxt).sendKeys(cty);
}

public void enterPosCode(String pscode) {
	driver.findElement(codebox).sendKeys(pscode);
}

public void clickDropDown(String countryName) {
	//countryName = "Switzerland";
	//driver.findElement(dropDownButton).click();
	//private By countrySelect = By.xpath("//li[@data-value=\"Switzerland\"]");
	
     
	/*
	 * String xpath = "//li[@data-value = '" + countryName + "']"; WebElement
	 * countryOption = driver.findElement(By.xpath(xpath)); countryOption.click();
	 */
	WebElement element = driver.findElement(dropDownButton);

	Actions actions = new Actions(driver); 

	actions.moveToElement(element).click().perform();
	driver.findElement(By.xpath("//li[@data-value=\"Russia\"]")).click();
	
}

public void clickonSearchButton() {
	
	
	/*
	 * WebDriverWait wait = new WebDriverWait(driver, 20); WebElement button =
	 * wait.until(ExpectedConditions.elementToBeClickable(searchButton));
	 * button.click();
	 */
	  
	  WebDriverWait wait = new WebDriverWait(driver, 10);
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(searchButton)); 
	  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", element);
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, 20); WebElement button =
		 * wait.until(ExpectedConditions.elementToBeClickable(searchButton));
		 * 
		 * 
		 * // Scroll to element if needed JavascriptExecutor js =
		 * (JavascriptExecutor)driver;
		 * js.executeScript("arguments[0].scrollIntoView(true);", button);
		 * 
		 * 
		 * try { button.click(); } catch (ElementClickInterceptedException e) { //
		 * Handle overlapping element (e.g., scroll further, disable temporarily) // ...
		 * your logic here ... }
		 */
}

public void clicksideDropButton () {
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,8000)", "");
	
	WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(sideDropButton));
	((JavascriptExecutor)driver).executeScript("arguments[0].click();", button);
	//button.click();
	
	
	
	//js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	//driver.findElement(sideDropButton).click();
	//js.executeScript("arguments[0].scrollIntoView();", element);
	//element.click();
	//Actions actions = new Actions(driver)
    //actions.moveToElement(driver.findElement(sideDropButton)).perform();
	
}


}
