package com.pages;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.google.common.collect.Range;


public class FacctViewWelcomePage {
	
	private WebDriver driver;
	private By sideBarListone = By.xpath("//*[@id=\"sidebarContent\"]/ul[1]/li/div/div[2]/p");
	private By sideBarfirst = By.xpath("//*[@id=\"sidebarContent\"]/ul[1]/li[1]/div/div[2]/p");
	private By entList = By.xpath("//*[@id=\"menu-\"]/div[3]/ul/li");
	private By clickArrow = By.xpath("//*[@id=\"entityType\"]");
	private By clickAny = By.xpath("//*[@id=\"menu-\"]/div[3]/ul/li[1]");
	private By clickInd = By.xpath("//*[@id=\"menu-\"]/div[3]/ul/li[2]");
	private By clickEnt = By.xpath("//*[@id=\"menu-\"]/div[3]/ul/li[3]");	
	private By interName =By.xpath("//*[@id=\":ro:\"]");
	//private By searchButton = By.xpath("//*[@id=\"searchInput\"]/div/div[3]/span/button[1]");
	private By searchButton = By.xpath("//input[@aria-invalid=\"false\" and @aria-label=\"Search\"]");
	private By extraFieldButton = By.xpath("//*[@id=\"searchInput\"]/div[1]/div[3]/span/button[2]");
	private By dateofBirth_reg =By.xpath("//*[@id=\":rp:\"]");
	private By natID_EntID =By.xpath("//*[@id=\"national-id\"]");
	private By searchResult = By.xpath("//*[@id=\"fv-summary-wrapper\"]/div[2]/b");
	private By downJson = By.xpath("//*[@id=\"json\"]/span[1]");
	private By popupVerify =By.xpath("//*[@id=\"7\"]");
	//private By blocklistName = By.xpath("/html/body/div[1]/div/div/div[1]/div[3]/div[4]/div[3]/div/div[2]/div[2]/div[1]/div/span[1]/div[2]/h6/div");
	private By blocklistName = By.tagName("h6");
	private By parentElement = By.xpath("//*[@id=\"searchResultContainer\"]");
	

	
	
	
	public FacctViewWelcomePage(WebDriver driver) {
		this.driver = driver;
		
	}
	
	public List<String> sidebarFirstList() {
		
		List<String> sideList = new ArrayList<>();
		List<WebElement> sideBarList = driver.findElements(sideBarListone);
		for (WebElement e : sideBarList)
		{
			String text =e.getAttribute("textContent");
		    System.out.println("getting Text: "+text);
		    sideList.add(text);
		}
		System.out.println("Printing second element :"+ driver.findElement(sideBarfirst).getAttribute("textContent"));
		return sideList;
	}
	
	public int getsideBarListOneCount() {
		
		return driver.findElements(sideBarListone).size();
	}
	
	public void clickSearch() {
		
		driver.findElement(sideBarfirst).click();
		
	}
    public void clickArrow() {
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(clickArrow).click();
		
	}
	public List<String> getEntityType(){
		
		List<String> entityList = new ArrayList<>();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Select s =new Select(driver.findElement(entList));
	//	List<WebElement> entls = s.getOptions();
		List<WebElement> entls = driver.findElements(entList);
		
		for (WebElement e : entls)
		{
			String text =e.getAttribute("textContent");
		    System.out.println("getting Text from Entity List: "+text);
		    entityList.add(text);
		}
		
		
		return entityList;
		
	}
	
	public void selectAny() {
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(clickAny).click();
		
	}
	
	public void selectInt() {
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(clickInd).click();
		
	}
	public void selectEntity() {
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(clickEnt).click();
		
	}
	
	public void enterNameforSearch(String name) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(interName).sendKeys(name);
	}
	
	public void clickSearchButton() {
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(searchButton).click();
		
	}

	public void extraFieldForSearch() {
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(extraFieldButton).click();
		
	}
	
	public void enterNIDorEntID(String idtype) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(natID_EntID).sendKeys(idtype);
	}
	public void enterdateofBirth(String dob) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(dateofBirth_reg).sendKeys(dob);
	}
	
	public String searchResult() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		return driver.findElement(searchResult).getText();
	}
	public void downloadJson() {
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		driver.findElement(downJson).click();
		
	}
	
	public String alertcaptur() {
		Alert alert = driver.switchTo().alert();
		String text = alert.getText();
		return text;
	}
	public String verifyPopupMessage() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		return driver.findElement(popupVerify).getText();
	}
	
	public String blockListName() {
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		//return driver.findElement(blocklistName).getText();
		//WebElement sectionThreeText = driver.findElement(By.tagName("h6"));
		List<WebElement> childs = driver.findElements(By.tagName("h6"));
//		for(WebElement e: childs )
//		{
//		    System.out.println("BL Names :  "+e.getText());
//		    System.out.println("BL Id's :" + e.getAttribute("id"));
//		}
//		
		////*div/span[1]/div[1]/span
//		
//		List<WebElement> allnodes = driver.findElements(By.xpath("//*div/span[1]/div[1]/span"));
//		for(WebElement e: childs )
//		{
//		    System.out.println("XPATHBL Names :  "+e.getText());
//		    System.out.println("BL XPATH Id's :" + e.getAttribute("id"));
//		}
//		
		
		
		return driver.findElement(blocklistName).getText();
	}
	
public List<String> searchListContainerName() throws InterruptedException {
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		WebElement sectionThreeText = driver.findElement(By.xpath("//*[@id=\"searchResultContainer\"]/div[2]"));
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	
		List<WebElement> score = sectionThreeText.findElements(By.xpath("./div/div/span[1]/div[1]"));
		List<WebElement> name = sectionThreeText.findElements(By.tagName("h6"));
		List<String> names =new ArrayList<>();
		List<String> scores =new ArrayList<>();			
				
		//System.out.println("Score Size list:"+name.size());
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		if(score.size()>0 && score.size()==name.size()) {
			for(int i=0; i<score.size(); i++) {
				//System.out.println("Name inside loop Size list:"+name.get(i).getText());
				names.add(name.get(i).getText());
				scores.add(score.get(i).getText());
			}
			
		}
		
		//System.out.println("searchListContainerName:"+names);
		//System.out.println("Values from MAP score:"+scores);
		
		//return driver.findElement(blocklistName).getText();
		return names;
	}
	

public List<String> searchListContainerScore() throws InterruptedException {
	
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
	WebElement sectionThreeText = driver.findElement(By.xpath("//*[@id=\"searchResultContainer\"]/div[2]"));
	Thread.sleep(5000);
	//driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	
	List<WebElement> score = sectionThreeText.findElements(By.xpath("./div/div/span[1]/div[1]"));
	List<WebElement> name = sectionThreeText.findElements(By.tagName("h6"));
	List<String> names =new ArrayList<>();
	List<String> scores =new ArrayList<>();			
			
	//System.out.println("Score Size list:"+name.size());
	//driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	if(score.size()>0 && score.size()==name.size()) {
		for(int i=0; i<score.size(); i++) {
			//System.out.println("Name inside loop Size list:"+name.get(i).getText());
			//names.add(name.get(i).getText(), score.get(i).getText());
			names.add(name.get(i).getText());
			//System.out.println("Map Score :  "+score.get(i).getText());
			scores.add(score.get(i).getText());
		}
		
	}
	
	//System.out.println("searchListContainerScore:"+scores);
	
	//return driver.findElement(blocklistName).getText();
	return scores;
}
	
	
}
