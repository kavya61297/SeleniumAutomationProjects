package mytestrunner;

import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		
				features = {"src/test/resources/AppFeature/facctViewLogin.feature"},
				//features = {"src/test/resources/AppFeature/readExcelData.feature"},
		  //features = {"src/test/resources/AppFeature/facctViewSingleSearchAPI.feature"},
		//features = {"src/test/resources/AppFeature/interPoleDataLoad.feature"},
		//glue = {"stepDefenition", "AppHooks"},
				glue = {"stepDefenition"},
				monochrome = true , 
	//plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
				plugin = {"pretty", "html:target/HtmlReports/HtmlReports.html",
						"pretty", "json:target/JSONReports/JSONReports.json",
						"pretty", "junit:target/JunitReports/JunitReports.junit"}
		
		
		
		
		)

public class MyTestRunner {
	public static WebDriver driver;


	

}
