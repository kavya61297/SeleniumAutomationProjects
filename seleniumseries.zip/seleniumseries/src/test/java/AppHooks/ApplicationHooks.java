package AppHooks;

import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.qea.factory.DriverFactory;
import com.qea.utils.configReader;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;


public class ApplicationHooks {
	
	
	private DriverFactory driverFactory;
	private WebDriver driver;
	private configReader confReader;
	Properties prop;
	
/*Before any page launch the browser with help of hooks*/

	@Before(order = 0)
	public void getProperty() {
		
		confReader = new configReader();
		prop = confReader.init_pop();
	}

	@Before(order = 1)
	public void launchBrowser(){
		String browserName = prop.getProperty("browser");
		driverFactory =new DriverFactory();
		driver=driverFactory.init_driver(browserName);
		System.out.println("Driver is : "+ driver);
		
	}
	
	//for @After always will be executed in reverse order like 1 then 0
//	@After(order = 0)
//	public void quitBrowser() {
//		driver.quit();	
//	}
//	
	@After(order = 1)
	public void tearDown(Scenario scenario) {
		
		if(scenario.isFailed()) {
			String screenshotName = scenario.getName().replaceAll(" ","_");
			byte [] sourcePath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(sourcePath, "image/png", screenshotName);
			
		}
	}


}
