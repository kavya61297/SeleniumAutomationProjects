package stepDefenition;

import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.google.common.collect.Range;
import com.pages.FacctViewLoginPage;
//import com.pages.FacctViewLoginPage.CustomConditions;
import com.pages.FacctViewWelcomePage;
import com.pages.interpolRedDataExtraction;
import com.pages.loginPage;
import com.qea.factory.DriverFactory;
import com.qea.utils.ReadExcelFileReader;
import com.qea.utils.configReader;
import com.qea.utils.readExcelData;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import com.pages.loginPage;
import com.qea.factory.DriverFactory;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//import io.cucumber.messages.internal.com.google.common.collect.Range;
import junit.framework.Assert;
import mytestrunner.MyTestRunner;


public class FacctViewLoginStep {
	
	
//private loginPage loginpage =new loginPage(DriverFactory.getDriver());
//private FacctViewLoginPage facctLgPage =new FacctViewLoginPage(DriverFactory.getDriver());
private FacctViewWelcomePage fcWelcomepg = new FacctViewWelcomePage(DriverFactory.getDriver());
private interpolRedDataExtraction interpolR = new interpolRedDataExtraction(DriverFactory.getDriver());
private readExcelData readex = new readExcelData();
ArrayList id = new ArrayList<>();
ArrayList searchName = new ArrayList<>();
ArrayList noofRecord = new ArrayList<>();
ArrayList matchName = new ArrayList<>();
ArrayList startRange = new ArrayList<>();
ArrayList endRange = new ArrayList<>();
ArrayList nameforComparision = new ArrayList<>();
ArrayList ListURL = new ArrayList<>();
ArrayList<Integer> startRangeforCom = new ArrayList<>();
ArrayList<Integer> endRangeforComp = new ArrayList<>();




	
	public WebDriver driver;
		public configReader confReader= new configReader();
	Properties prop = confReader.init_pop();
	 
	public int noofrecords;
	FacctViewLoginPage loginPage;
	//@Before
	//public void beforeScenario() {
	    // Access the driver instance from the test runner
	   // WebDriver driver = MyTestRunner.getDriver();

	    // Use the driver instance in your step definitions
	    // ...
	//}
	/*
	 * @Before public static void setup() { driver = new ChromeDriver(); // Replace
	 * with your desired browser driver }
	 */
	@Before
	public void setup() {
	
		System.out.println("Inside setup");
		driver = DriverFactory.init_driver(prop.getProperty("browser")); // Replace "chrome" with desired browser
	} 
	
	@Given("I Open url {string}")
	public void i_Open_URL(String uRL) {
		loginPage=new FacctViewLoginPage(driver);
		System.out.println("Driver Value  :"+ driver);
		
		
		System.out.println("URL : " +prop.getProperty(uRL));
		 //Dimension screenSize = driver.manage().window().getSize();
		// driver.manage().window().setSize(screenSize);
		driver.get(prop.getProperty(uRL));
		//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Login to FacctView");
	   
	}
	
	/*@Given("I Open given url {string}")
	public void i_Open_GIVEN_URL(String URL) {
		
		driver.get(URL);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Login to FacctView");
	   
	}*/
	//@SuppressWarnings("deprecation")
	//@Given("I validate Login page text {string}")
	//public void i_validate_login_page_text(String logintext) throws InterruptedException {
	//	Thread.sleep(9000);
	//	if (facctLgPage.getLoginPageText() != null) {
	//		  String lgtext = facctLgPage.getLoginPageText();
	//		  Assert.assertTrue(lgtext.contains(logintext));
	//		} else {
			  // Handle the case where the element is not found
	//		  System.out.println("Login page text element not found!");
	//		}
		
		//String lgtext=facctLgPage.getLoginPageText();
		//Assert.assertTrue(lgtext.contains(logintext));
		
		//System.out.println("Page Title is:" +facctLgPage.getLoginPageText());
	
	    // Write code here that turns the phrase above into concrete actions
	    
	//}
	/*public void i_validate_login_page_text(String logintext) {
	    WebDriverWait wait = new WebDriverWait(driver, 10); // Adjust timeout as needed
	     //loginPage = new FacctViewLoginPage(driver);

	    //String lgtext = wait.until(ExpectedConditions.(loginPage.getLoginPageText())).getText();

	    // Use JUnit Hamcrest for a more readable assertion
	  //  assertThat(lgtext, containsString(logintext));
	}*/
	
	//WebDriverWait wait = new WebDriverWait(driver, 10); // Adjust timeout as needed
	//String lgtext = wait.until(CustomConditions.textPresent("A cloud-first screening capability that is agile, fast"));
	//WebDriverWait wait = new WebDriverWait(driver, 10); // Adjust timeout as needed
	//String actualText = wait.until(CustomConditions.textPresent("A cloud-first screening capability that is agile, fast"));

	// Assert that the actual text contains the expected text
	//assertThat(actualText, containsString(logintext));
	@Given("I click to facctView login button")
	public void I_click_to_facctView_login_button() {
		//FacctViewLoginPage facctLgPage = new FacctViewLoginPage(driver);
		loginPage.clickLoginButton();
	    // Write code here that turns the phrase above into concrete actions
		//confReader = new configReader();
		//prop = confReader.init_pop();
		//DriverFactory.getDriver().get(prop.getProperty(URL));
	    
	}

	@Given("I enter tenant name {string}")
	public void i_enter_tenant_name(String orgName) {
		loginPage.enterOrgName(orgName);
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Given("I click to continue button")
	public void i_click_to_continue_button() {
	    // Write code here that turns the phrase above into concrete actions
		loginPage.clickcontButton();
	    
	}

	@Given("I enter facctView login id {string}")
	public void i_enter_facct_view_login_id(String loginId)  {
		//confReader = new configReader();
		//prop = confReader.init_pop();
		//Thread.sleep(2000);
		//loginPage.enterUserName(prop.getProperty(loginId));
		loginPage.enterUserName(loginId);
		//DriverFactory.getDriver().get(prop.getProperty(URL));
	    // Write code here that turns the phrase above into concrete actions
	    //throws InterruptedException
	}

	@Given("I enter facctView login password {string}")
	public void i_enter_facct_view_login_password(String passwor) {
	    // Write code here that turns the phrase above into concrete actions
		//confReader = new configReader();
		//prop = confReader.init_pop();
		//loginPage.enterPassword(prop.getProperty(passwor));
		loginPage.enterPassword(passwor);
	}

	@Given("I click to next button")
	public void i_click_to_next_button() {
	    // Write code here that turns the phrase above into concrete actions
		loginPage.clickonLoginButtonT();
	    
	}

	@Then("I validate welcome page text {string}")
	public void i_validate_welcome_page_text(String pagetext) {
		System.out.println("Welcome page Title is:" +loginPage.getWelcomePageText());
		String pagetxt=loginPage.getWelcomePageText();
		Assert.assertTrue(pagetxt.contains(pagetext));
		
		System.out.println("Page Title is:" +loginPage.getWelcomePageText());
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("I validate list on sidebar{string}")
	public void i_validate_all_list_item() {
		
		
	}
	
	@Then("User uses search page {string}") 
		public void user_uses_search_page(String searchtext) {
		loginPage.searchText(searchtext);
		}
	
	@Then("I click dropdown")
	public void i_click_dropdown() {
		loginPage.clickDropButton();
	}
	
	@Then("User clicks dropdown button {string}")
	public void user_clicks_dropdown_button(String countryname) {
		loginPage.clickDropDown(countryname);
	}
	
	@Then("User enters idnumber {string}")
	public void user_enters_idnumber (String idnum) {
		
		loginPage.enterIdNumber(idnum);
		
	}
	
	
	@Then("User enters addressline {string}")
	public void user_enters_addressline(String addressline) {
		loginPage.enterAddressLine(addressline);
	}
	
	@Then("User enters city {string}")
	public void user_enters_city(String city) {
		loginPage.enterCity(city);
	}
	
	@Then("User enters postalcode {string}")
	public void user_enters_postalcode(String poscode) {
		loginPage.enterPosCode(poscode);
	}
	
	@Then("I click to search button")
	public void i_click_to_search_button() {
		loginPage.clickonSearchButton();
	}
	
	@Then("I click side drop button")
	public void i_click_side_drop_button() {
		loginPage.clicksideDropButton();
	}
	
	
	@Then("User enters data {string}")
	public void user_enters_data(String sheetname) throws InvalidFormatException, IOException {
	   String excelFilePath = "C:\\Users\\KavyaS\\Automation_Framework_Bkp\\seleniumseries\\src\\test\\resources\\testData\\dsAlgoData.xlsx";
		Object[][] testData = ReadExcelFileReader.getExcelData(sheetname,excelFilePath);
		
		/*
		 * for (Object[] testRow : testData) { String username = (String) testRow[0];
		 * String password = (String) testRow[1]; String tenantID = (String) testRow[2];
		 * String Inputtext = (String) testRow[3]; String addresstext = (String)
		 * testRow[4]; String country = (String) testRow[5]; String cityname = (String)
		 * testRow[6]; String pcode = (String) testRow[7]; int ID = (int) testRow[8];
		 * 
		 * loginPage.enterOrgName(tenantID); }
		 */
		/*
		 * if (testData.length > 0) { // Check if there's at least one row of data
		 * System.out.print("Row 1: "); for (Object value : testData[0]) { // Access the
		 * first row System.out.print(value + " "); // Print each value in the row }
		 * System.out.println(); // New line after the row } else {
		 * System.out.println("No data found in the specified sheet."); }
		 */

		    // Assuming your test data structure matches the previous code
		int numberOfRows = testData.length; // Get the total number of rows in the Excel file

		for (int i = 0; i < numberOfRows; i++) {
		    Object[] testRow = testData[i]; // Get the current row
		    String username = (String) testRow[0];
		    String password = (String) testRow[1];
		    String tenantID = (String) testRow[2];
		    String Inputtext = (String) testRow[3];
		    String addresstext = (String) testRow[4];
		    String country = (String) testRow[5];
		    String cityname = (String) testRow[6];
		    String pcode = (String) testRow[7];

		    // Handling ID, ensuring it's treated correctly
		    int ID;
		    if (testRow[8] instanceof Double) {
		        ID = ((Double) testRow[8]).intValue(); // Convert Double to int safely
		    } else {
		        ID = (int) testRow[8]; // Safe cast if it's already an Integer
		    }

		    // Proceed with login operations
		    loginPage.enterOrgName(tenantID);
		    loginPage.clickcontButton();
		    loginPage.enterUserName(username);
		    loginPage.enterPassword(password);
		    loginPage.clickonLoginButtonT();
		    loginPage.searchText(Inputtext);
		    loginPage.clickDropButton();
		    loginPage.enterIdNumber(String.valueOf(ID));
		    loginPage.enterAddressLine(addresstext);
		    loginPage.enterCity(cityname);
		    loginPage.enterPosCode(pcode);
		    loginPage.clickonSearchButton();
		}
		
		
		/*
		 * for (int i = 0; i < testData.length; i++) { for (int j = 0; j <
		 * testData[i].length; j++) { System.out.print(testData[i][j] + "\t"); }
		 * System.out.println(); }
		 */
		
	}
	
	
	
	/*
	 * @Then("user gets first list") public void
	 * user_gets_first_list(io.cucumber.datatable.DataTable sideListTable) {
	 * 
	 * // Write code here that turns the phrase above into concrete actions // For
	 * automatic transformation, change DataTable to one of // E, List<E>,
	 * List<List<E>>, List<Map<K,V>>, Map<K,V> or // Map<K, List<V>>. E,K,V must be
	 * a String, Integer, Float, // Double, Byte, Short, Long, BigInteger or
	 * BigDecimal. List<String> exceptsideList=sideListTable.asList();
	 * System.out.println("Expected Table List:"+exceptsideList); List<String>
	 * actualtsideList=fcWelcomepg.sidebarFirstList();
	 * System.out.println("Actual Table List:"+actualtsideList);
	 * Assert.assertTrue(exceptsideList.containsAll(actualtsideList)); }
	 */

//	@Then("listone count should be {int}")
//	public void listone_count_should_be(Integer int1) {
//		Assert.assertTrue(fcWelcomepg.getsideBarListOneCount() == int1);
//	    // Write code here that turns the phrase above into concrete actions
//	    
//	}
	
//	@Then("check more outcomes")
//	public void check_more_outcomes() {
//	    // Write code here that turns the phrase above into concrete actions
//	    
//	}
//	
//	@Given("user click on arrow list")
//	public void click_arrow(){
//		
//		fcWelcomepg.clickArrow();
//		
//	}
//	
//	@Then("user gets entity list")
//	public void user_gets_EntityListDropdown(io.cucumber.datatable.DataTable entLst) {
//		
//	    // Write code here that turns the phrase above into concrete actions
//	    // For automatic transformation, change DataTable to one of
//	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
//	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
//	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
//	    List<String> exceptedeList=entLst.asList();
//	    System.out.println("Expected Entity List:"+exceptedeList);
//	    List<String> actualeList=fcWelcomepg.getEntityType();
//	    System.out.println("Actual Entity List:"+actualeList);
//	    Assert.assertTrue(exceptedeList.containsAll(actualeList));
//	    
//
//
//	}
	
	@Given("User selects Individual from list")
	public void user_selects_individual_from_list() {
	   fcWelcomepg.selectInt();
	    
	}
	@Given("User selects Any from list")
	public void user_selects_any_from_list() {
	   fcWelcomepg.selectAny();
	    
	}
	@Given("User selects entity from list")
	public void user_selects_entity_from_list() {
	   fcWelcomepg.selectEntity();
	    
	}
	
	
	
	@Then("^User validate result is displayed from excel \"([^\"]*)\"$")
	public void user_validate_result_is_displayed_from_excel(String Name) throws IOException {
    String sactual = fcWelcomepg.searchResult();
    int noofrecords = Integer.parseInt(sactual.replaceAll("[^0-9]", ""));
    System.out.println("number of list displayed : "+ noofrecords);
	ArrayList searchName = new ArrayList<>();
	ArrayList numRecord = new ArrayList<>();
	int indexofn,indexofname = 0, firstindexofname=0,lastindexofname=0;;
	String actualscore=null, aname=null;
	searchName=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,1);
	numRecord=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,2);
	Set uniqueName = new HashSet<>(searchName);
	 List list = new ArrayList<String>(uniqueName); 
	System.out.println("Unique Values of names for search  "+uniqueName);
	if(list.contains(Name)) {
		indexofname =list.indexOf(Name);
		System.out.println("Index of Given Name"+indexofname +"Unq N :  "+Name);	
	}
	System.out.println("Type of data of number from Excel : "+ (numRecord.get(firstindexofname)).getClass().getName());
	firstindexofname=searchName.indexOf(list.get(indexofname));
	int recExc =Integer.valueOf((String) (numRecord.get(firstindexofname)));
	System.out.println("Number of Record from excel validation "+numRecord.get(firstindexofname));
	Assert.assertEquals(noofrecords,recExc);
	
}


	
	@Before public void loader () throws InterruptedException, IOException {
		
		id=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,0);
		searchName=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,1);
		noofRecord=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,2);
		matchName=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,3);
		startRange=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,4);
		endRange=readex.readExcel("./src\\test\\resources\\testData", "Test_Sheet.xlsx", 2,5);
		
	}

	@Then("^User verifies all the result from excel for search \"([^\"]*)\"$")
	public void user_verifies_All_the_result(String Name)  throws InterruptedException, IOException {
		
		//String actual msg=fcWelcomepg.verifyPopupMessage();
		List<String> uiNameList = fcWelcomepg.searchListContainerName();
		Thread.sleep(6000);
		List<String> uiScoreList = fcWelcomepg.searchListContainerScore();
		
		int indexofn,indexofname = 0, firstindexofname=0,lastindexofname=0;;
		String actualscore=null, aname=null;
		
		Set uniqueName = new HashSet<>(searchName);
		 List list = new ArrayList<String>(uniqueName); 
		System.out.println("Unique Values of names for search  "+uniqueName);
		if(list.contains(Name)) {
			indexofname =list.indexOf(Name);
			//System.out.println("Index of Given Name"+indexofname +"Unq N :  "+Name);
			
		}
		System.out.println("Last of first unique Values Name Value "+searchName.lastIndexOf(list.get(indexofname)));
		System.out.println("First Index of first unique Values Name Value "+searchName.indexOf(list.get(indexofname)));
		firstindexofname=searchName.indexOf(list.get(indexofname));
		lastindexofname=searchName.lastIndexOf(list.get(indexofname));
		for(int i=firstindexofname;i<=lastindexofname; i++) {
			nameforComparision.add(matchName.get(i));
			//System.out.println("range..."+ startRange.get(i));
			int stran = (int)(double)(startRange.get(i));
			int enran =(int)(double)endRange.get(i);
			Integer sr = new Integer(stran);
			Integer er = new Integer(enran);
			startRangeforCom.add(sr);
			endRangeforComp.add(er);
		}
		System.out.println("List of name for comparision from Excel "+ nameforComparision);
		//System.out.println("Comparision Result:  "+ uiNameList.containsAll(nameforComparision));
		
		System.out.println("Result of Name List from UI  "+uiNameList);
		if(uiNameList.size()>0 && nameforComparision.size()>0)
		{
			
			for(int i=0;i<nameforComparision.size(); i++) {
				
				indexofn=uiNameList.indexOf(nameforComparision.get(i));
				//System.out.println("Index of name from UI "+ indexofn);
				
			//	System.out.println("1  "+System.currentTimeMillis());
				actualscore=uiScoreList.get(indexofn);
				//System.out.println("2  "+System.currentTimeMillis());
				aname=uiNameList.get(indexofn);
				System.out.println("Name from UI "+ aname);
				System.out.println("Name from excel : "+ nameforComparision.get(i)+"   :Name from UI : "+ aname);
				System.out.println("Given Start Range "+ startRangeforCom.get(i));
				System.out.println("Given End Range "+ endRangeforComp.get(i));
				System.out.println("Score from UI "+ actualscore);
				Range<Integer> openClosed = Range.openClosed(startRangeforCom.get(i),endRangeforComp.get(i));
				
				 Assert.assertTrue(aname.equals(nameforComparision.get(i)));
				  Assert.assertTrue(openClosed.contains(Integer.parseInt(actualscore)));
				  
				
			}
		
		}
		
		

	}

	
	@Then("^User downloads all the link from CBI")
	public void user_download() throws InterruptedException {
		
		interpolR.getAllLinkandName();
	}
	@Then("^User click Next button")
	public void user_clicknxt() throws InterruptedException {
		
		interpolR.clickNext();
	}

	
	@Then("^User get all the details from page")	
public void i_get_Open_GIVEN_URL() throws IOException, InterruptedException {
		ArrayList ListURL = new ArrayList<>();
		ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
		ArrayList<String> familyName = new ArrayList<>();
		ArrayList<String> gender = new ArrayList<>();
		ArrayList<String> dateofbirth = new ArrayList<>();
		ArrayList<String> placeofbirth = new ArrayList<>();
		ArrayList<String> language = new ArrayList<>();
		ArrayList<String> charges = new ArrayList<>();
		ListURL.size();
		DriverFactory dd = new DriverFactory();
		System.out.println("List Size " + ListURL.size());
		for(int i=0;i<ListURL.size(); i++) {
			ListURL.get(i);
			dd.getDriver().get((String) ListURL.get(i));
			Thread.sleep(8000);
			familyName.add(interpolR.getFamilyName());
			gender.add(interpolR.getGender());
			dateofbirth.add(interpolR.getDob());
			placeofbirth.add(interpolR.getPob());
			language.add(interpolR.getlang());
			charges.add(interpolR.getcharge());
			System.out.println(interpolR.getName() +" ~ "+interpolR.getFamilyName()+"~ "+interpolR.getGender()+" ~"+interpolR.getDob()+"~ "+interpolR.getPob()+"~ "+interpolR.getlang()+"~"+interpolR.getcharge());
			
		}
		System.out.println("Printing familyname------- " + familyName );

	
}
	@Then("^User get all the details for family from page")	
	public void i_get_Open_family() throws IOException, InterruptedException {
			ArrayList ListURL = new ArrayList<>();
			ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
			ListURL.size();
			DriverFactory dd = new DriverFactory();

			for(int i=0;i<ListURL.size(); i++) {
				ListURL.get(i);
				dd.getDriver().get((String) ListURL.get(i));
				Thread.sleep(4000);
				System.out.println(interpolR.getFamilyName());
				
			}

	}

	@Then("^User get all the details for gender from page")	
	public void i_get_Open_gender() throws IOException, InterruptedException {
			ArrayList ListURL = new ArrayList<>();
			ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
			ListURL.size();
			DriverFactory dd = new DriverFactory();
			for(int i=0;i<ListURL.size(); i++) {
				ListURL.get(i);
				dd.getDriver().get((String) ListURL.get(i));
				Thread.sleep(4000);
				System.out.println(interpolR.getGender());
				
			}

	}

	@Then("^User get all the details for dateofb from page")	
	public void i_get_Open_dob() throws IOException, InterruptedException {
			ArrayList ListURL = new ArrayList<>();
			ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
			ListURL.size();
			DriverFactory dd = new DriverFactory();
			for(int i=0;i<ListURL.size(); i++) {
				ListURL.get(i);
				dd.getDriver().get((String) ListURL.get(i));
				Thread.sleep(4000);
				System.out.println(interpolR.getDob());}
			}
			
			@Then("^User get all the details for pod from page")	
			public void i_get_Open_pod() throws IOException, InterruptedException {
					ArrayList ListURL = new ArrayList<>();
					ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
					ListURL.size();
					DriverFactory dd = new DriverFactory();
					for(int i=0;i<ListURL.size(); i++) {
						ListURL.get(i);
						dd.getDriver().get((String) ListURL.get(i));
						Thread.sleep(4000);
						System.out.println(interpolR.getPob());
						
					}

		
	}
			@Then("^User get all the details for nati from page")	
			public void i_get_Open_nat() throws IOException, InterruptedException {
					ArrayList ListURL = new ArrayList<>();
					ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
					ListURL.size();
					DriverFactory dd = new DriverFactory();
					for(int i=0;i<ListURL.size(); i++) {
						ListURL.get(i);
						dd.getDriver().get((String) ListURL.get(i));
						Thread.sleep(4000);
						System.out.println(interpolR.getnation());
						
					}

		
	}

			@Then("^User get all the details for lan from page")	
			public void i_get_Open_lan() throws IOException, InterruptedException {
					ArrayList ListURL = new ArrayList<>();
					ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
					ListURL.size();
					DriverFactory dd = new DriverFactory();
					for(int i=0;i<ListURL.size(); i++) {
						ListURL.get(i);
						dd.getDriver().get((String) ListURL.get(i));
						Thread.sleep(4000);
						System.out.println(interpolR.getlang());
						
					}

		
	}
			
			@Then("^User get all the details for charge from page")	
			public void i_get_Open_char() throws IOException, InterruptedException {
					ArrayList ListURL = new ArrayList<>();
					ListURL=readex.readExcel("C:\\Users\\ReemaSingh\\OneDrive - FACCTUM IT SOLUTIONS INDIA PRIVATE LIMITED\\Desktop", "Interpole_List.xlsx", 0,0);
					ListURL.size();
					DriverFactory dd = new DriverFactory();
					for(int i=0;i<ListURL.size(); i++) {
						ListURL.get(i);
						dd.getDriver().get((String) ListURL.get(i));
						Thread.sleep(4000);
						System.out.println(interpolR.getcharge());
						
					}

		
	}
			
}
