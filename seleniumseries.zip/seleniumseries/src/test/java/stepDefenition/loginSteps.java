package stepDefenition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pages.loginPage;
import com.qea.factory.DriverFactory;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class loginSteps {
	
	private loginPage loginpage =new loginPage(DriverFactory.getDriver());
	
	WebDriver driver;
	
	
	@Given("I click on URL")
	public void i_click_on_URL() {
		DriverFactory.getDriver().get("https://stage-saas.facctum.com/facctlist");
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Login to Facctlist");
	   
	}
	
	@Given("I verify login page by welcome text")
			public void i_validate_login_page_text(String logintext) throws InterruptedException {
			Thread.sleep(2000);
			String lgtext=loginpage.getfirstPageText();
			Assert.assertTrue(lgtext.contains("Welcome to"));
			
			System.out.println("Page Title is:" +loginpage.getfirstPageText());
	}
	
	@Given("I click on login button")
	public void i_click_on_login_button() {
	    loginpage.clickLogin();;
		// Write code here that turns the phrase above into concrete actions
	 
	}

	@Given("I enter my organization name {string}")
	public void i_enter_my_organization_name(String orgname) {
			loginpage.enterOrgName(orgname);
	    // Write code here that turns the phrase above into concrete actions
	
	}

	@Given("I press continue key")
	public void i_press_continue_key() {
	    // Write code here that turns the phrase above into concrete actions
		loginpage.clickOnContinue();
	 
	}

	@Given("I press continue key to Login to Dashboard")
	public void i_press_continue_key_to() {
	    // Write code here that turns the phrase above into concrete actions
		loginpage.clickToContinue();
	 
	}
	
	@When("Users enters the login page")
	public void users_enters_the_login_page() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("user enters the login id")
	public void user_enters_the_login_id() {
//		List<String> asList = dt.asList();
//		String emailid =asList.get(0);
//		String reason =asList.get(1);
//	    // DataTable dt Write code here that turns the phrase above into concrete actions
//	    passListpage.clickNewList();
//	    passListpage.enterPrivatePasslistDetails(passlistname,reason);
		//String emailId="Globalhead@natwestpoc.com";
		String emailId="globalhead@datavium.com";
		//String emailId="nwgh@natwestpoc.com";
		loginpage.enterUserName(emailId);
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@When("user enters the password")
	public void user_enters_the_password() {
		//String passwd="Natwest@1";
		String passwd="Test@123";
		loginpage.enterPassword(passwd);		
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
	    // Write code here that turns the phrase above into concrete actions
	 
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String titlepg) {
	    // Write code here that turns the phrase above into concrete actions
		String title=loginpage.titlePage();
		Assert.assertTrue(title.contains(titlepg));
		
		System.out.println("Page Title is:" +loginpage.titlePage()); 
	   
	}


}
