import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DemoAutomation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver","C:\\eclipse\\BrowserDrivers\\chromedriver.exe");
			ChromeDriver driver = new ChromeDriver();
			driver.get("https://patinformed.wipo.int/");
			
			driver.manage().window().maximize();
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			
			
			WebElement dropdownButton = driver.findElement(By.xpath("//span[@class='dropdown-btn' and contains(., 'Countries filter')]"));
            dropdownButton.click();

            // 2. Wait for the checkbox list to appear (using explicit wait)
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@class='multiselect-item-checkbox']/input[@aria-label='EP - European Patent Office']")));

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            // 3. Find and click the checkbox for "EP - European Patent Office"
          //  WebElement checkbox = driver.findElement(By.xpath("//li[@class='multiselect-item-checkbox']/input[@aria-label='EP - European Patent Office']"));
           // checkbox.click();
            
            WebElement checkbox = driver.findElement(By.xpath("//li[@class='multiselect-item-checkbox']/input[@aria-label='EP - European Patent Office']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox);
            
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    		WebElement rbutton = driver.findElement	(By.xpath("//button[@class='green' and text()='I have read and agree to the terms']"));
    		rbutton.click();
            
            
            WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement divElement1 = wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[contains(@class, 'medNum') and contains(@class, 'card') and contains(@class, 'titlePreview')]/div[@class='title cropper']")));
			divElement1.click();
			
			
			WebElement dateElement1 = driver.findElement(By.xpath("(//tr/td[@class='nobreak'])[1]"));
	        WebElement dateElement2 = driver.findElement(By.xpath("//td[@class='flex column']/span[@class='nobreak']"));

	        String date1Str = dateElement1.getText();  // Example: "2004-01-15"
	        String date2Str = dateElement2.getText();  // Example: "2003-08-30"

	        
	        String date1Only = date1Str.substring(0, 10);
            String date2Only = date2Str.substring(0, 10);
	        // Define date format
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	        // Convert strings to Date objects
	       // Date date1 = sdf.parse(date1Str);
	       // java.util.Date startDate = format.parse(req.getParameter("startDate"));
	       // Date date2 = sdf.parse(date2Str);
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	        LocalDate date1 = LocalDate.parse(date1Only, formatter);
	      //  LocalDate startDate = LocalDate.parse(req.getParameter("startDate"), formatter);
	        LocalDate date2 = LocalDate.parse(date2Only, formatter);


	        // Calculate the difference in milliseconds
	    //    long diffInMillies = Math.abs(date1.getTime() - date2.getTime());
	        long daysBetween = ChronoUnit.DAYS.between(date1, date2);
	        long absoluteDaysBetween = Math.abs(daysBetween);

	        // Convert milliseconds to days, months, and years
	       // long diffInDays = TimeUnit.DAYS.convert(absoluteDaysBetween, TimeUnit.MILLISECONDS);
	        long diffInDays = absoluteDaysBetween;
	        long diffInYears = diffInDays / 365;
	        long diffInMonths = diffInDays / 30;

	        // Print the results
	        System.out.println("Difference in Days: " + diffInDays);
	        System.out.println("Difference in Months: " + diffInMonths);
	        System.out.println("Difference in Years: " + diffInYears);
			
          //li[contains(@class, 'medNum') and contains(@class, 'card') and contains(@class, 'titlePreview')]/div[@class='title cropper']
			
			//driver.getElementById("")
			
			
			//WebElement searchBtn = driver.findElement(By.xpath("//button[@class=\"margin-right\"]"));
			//searchBtn.click();
			
			
			
			//WebElement readBtn = driver.findElement(By.xpath("//button[@class='green' and text()='I have read and agree to the terms']"));
			//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(500)); // Adjust timeout as needed
			//WebElement rbutton = wait.until(ExpectedConditions.elementToBeClickable
			
			
			
		//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//	WebElement rbutton = driver.findElement	(By.xpath("//button[@class='green' and text()='I have read and agree to the terms']"));
			
			
			//JavascriptExecutor executor = (JavascriptExecutor)driver;
			//executor.executeScript("arguments[0].click();", rbutton);
			//rbutton.click();
			
			//WebDriverWait waitforDiv = new WebDriverWait(driver, Duration.ofSeconds(10));
           // WebElement divElement = waitforDiv.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'title') and contains(@class, 'cropper') and contains(text(), 'STABLE POLYMORPH')]")));
			//driver.findElement(By.xpath("//div[contains(@class, 'title') and contains(@class, 'cropper') and contains(text(), 'STABLE POLYMORPH')]")).click();
			//divElement.click();
			
		//	WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
		//	WebElement divElement1 = wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'title') and contains(@class, 'cropper') and contains(text(), 'FILM-COATED SCORED TABLET')]")));
		//	divElement1.click();
			
			
			
	}

}
